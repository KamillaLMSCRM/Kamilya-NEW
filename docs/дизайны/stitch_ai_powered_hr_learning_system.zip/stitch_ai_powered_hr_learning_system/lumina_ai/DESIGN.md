---
name: Lumina AI
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#464555'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#005338'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is engineered for an **Innovative Assistant** LMS, focusing on a personality that is supportive, intelligent, and forward-thinking. The visual language utilizes a "Soft Tech" aesthetic—merging the precision of high-end software with the approachable warmth of a personal tutor. 

The style leverages **Glassmorphism** for secondary surfaces to maintain a sense of depth and transparency, while **Minimalism** governs the layout to ensure the AI-driven data is never overwhelming. The goal is to evoke a sense of calm focus and intellectual empowerment through soft-edged containers and rhythmic whitespace.

## Colors
The palette is rooted in a "Futuristic Indigo" and "Deep Violet" core to represent intelligence and the AI frontier. 

- **Primary (Indigo):** Used for primary actions, navigation states, and branding.
- **Secondary (Violet):** Reserved for AI-specific interactions, highlights, and generative states to distinguish human-driven vs. machine-driven content.
- **Success (Emerald):** Applied to progress rings, completion states, and positive feedback loops.
- **Background (Slate 50):** A soft, cool neutral that reduces eye strain during long learning sessions.

Gradients should be used sparingly, primarily as subtle backgrounds for AI-driven "Assistant" cards, transitioning from Indigo to Violet at a 135-degree angle.

## Typography
The typography system uses **Inter** for its exceptional legibility and systematic feel. The hierarchy is strictly enforced to guide the user through complex educational material. 

Headlines utilize a tighter letter-spacing and heavier weights to feel "grounded," while body text maintains generous line-heights for readability. Labels and captions use medium to semi-bold weights to ensure they stand out against the soft UI backgrounds.

## Layout & Spacing
The layout follows a **Fluid Grid** system with a focus on "bento-style" card arrangements. 

- **Desktop:** 12-column grid with 24px gutters. Content is housed in cards that typically span 3, 4, 6, or 12 columns.
- **Tablet:** 8-column grid with 20px gutters. 
- **Mobile:** 4-column grid with 16px margins. 

Vertical rhythm is maintained using a 4px base unit. AI Assistant elements should have increased internal padding (32px+) to signify their importance and provide "breathing room" for generative content.

## Elevation & Depth
This design system avoids harsh shadows in favor of **Tonal Layers** and **Glassmorphism**.

1.  **Level 0 (Background):** Slate 50.
2.  **Level 1 (Standard Cards):** Pure White with a very soft, 10% opacity Indigo shadow (4px Y, 12px Blur).
3.  **Level 2 (AI/Interactive Cards):** Glassmorphism effect—White at 70% opacity with a 12px backdrop-blur and a subtle 1px semi-transparent white border.
4.  **Level 3 (Modals/Popovers):** Pure White with a 15% opacity Indigo shadow (12px Y, 24px Blur).

Depth is communicated through transparency and blur rather than darkness, maintaining the "light and airy" feel of a modern assistant.

## Shapes
The shape language is defined by significant roundedness to reinforce the "Supportive" and "User-friendly" brand pillars. 

- **Containers/Cards:** Use a `2xl` radius (1.5rem / 24px) to create a friendly, soft appearance.
- **Buttons/Inputs:** Use a `lg` radius (1rem / 16px) for a modern, tactile feel.
- **Progress Elements:** Rings and bars use fully rounded caps (Pill-shaped) for a fluid, organic look.

## Components
### Buttons
Primary buttons use the Indigo-to-Violet gradient with white text. Secondary buttons are "Ghost" style with a 1px Indigo border. AI-action buttons feature a subtle "shimmer" animation to indicate intelligence.

### AI Generation Cards
These are the signature components. They must use the Glassmorphism style with a 1.5px border that uses a subtle gradient. Content within should animate in (fade and slide) to represent real-time generation.

### Progress Rings
Success states use a 4px stroke width in Emerald. Incomplete states use a soft Slate 200. The center of the ring displays the percentage in `label-md` typography.

### Input Fields
Inputs should be large (48px height) with a soft Slate 100 background. On focus, the border transitions to Indigo with a 2px outer glow (4px spread, Indigo 10% opacity).

### Data Visualizations
Charts should use rounded line caps and soft area fills. The color palette for data must prioritize Indigo, Violet, and Emerald to stay cohesive with the brand.